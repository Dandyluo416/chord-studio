from pathlib import Path
import shutil
root=Path(__file__).resolve().parent.parent
out=root/'dist'
out.mkdir(exist_ok=True)
for name in ['index.html','css','js','assets','sw.js','manifest.webmanifest','icon-192.png','icon-512.png','apple-touch-icon.png']:
 p=root/name
 if p.is_dir():shutil.copytree(p,out/name,dirs_exist_ok=True)
 else:shutil.copy2(p,out/name)
print('Static dist ready')
