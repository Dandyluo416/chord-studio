const assert=require('node:assert/strict');const {build,normalize}=require('../js/chord-engine.js');
const cases=[
 [{},'C',['C','E','G'],[0,4,7]],
 [{quality:'minor',seventh:'7'},'Cm7',['C','E♭','G','B♭'],[0,3,7,10]],
 [{seventh:'maj7',adds:[9]},'Cmaj7(add9)',['C','E','G','B','D'],[0,4,7,11,14]],
 [{quality:'sus4',seventh:'7'},'C7sus4',['C','F','G','B♭'],[0,5,7,10]],
 [{adds:[6]},'C6',['C','E','G','A'],[0,4,7,9]],
 [{adds:[9,6]},'C6/9',['C','E','G','A','D'],[0,4,7,9,14]],
 [{quality:'dim',seventh:'7'},'Cm7♭5',['C','E♭','G♭','B♭'],[0,3,6,10]],
 [{quality:'dim',seventh:'dim7'},'Cdim7',['C','E♭','G♭','B𝄫'],[0,3,6,9]],
 [{quality:'dim',seventh:'maj7'},'Cdim(maj7)',['C','E♭','G♭','B'],[0,3,6,11]],
 [{letter:'F',acc:1,seventh:'maj7'},'F♯maj7',['F♯','A♯','C♯','E♯'],[0,4,7,11]],
 [{letter:'C',acc:-1},'C♭',['C♭','E♭','G♭'],[0,4,7]],
 [{seventh:'7',alterations:['♭9']},'C7(♭9)',['C','E','G','B♭','D♭'],[0,4,7,10,13]],
 [{extension:13,alterations:['♯11']},'C13(♯11)',['C','E','G','B♭','D','F♯','A'],[0,4,7,10,14,18,21]],
];for(const [s,name,notes,ints]of cases){const c=build(s);assert.equal(c.symbol,name);assert.deepEqual(c.components.map(t=>t.name),notes);assert.deepEqual(c.components.map(t=>t.offset),ints)}
for(const [s,name,bass]of [[{inversion:1},'C/E',4],[{inversion:2},'C/G',7],[{seventh:'7',inversion:3},'C7/B♭',10],[{extension:9,inversion:1},'C9/E',4]]){const c=build(s);assert.equal(c.symbol,name);assert.equal(c.bass.pc,bass);assert.ok(c.voiced.every((n,i,a)=>!i||n.midi>a[i-1].midi))}
const a=build({seventh:'maj7',adds:[11,9]}),b=build({adds:[9,11],seventh:'maj7'});assert.deepEqual(a,b);
let tested=0;for(const letter of 'CDEFGAB')for(const acc of [-1,0,1])for(const quality of ['major','minor','dim','aug','sus2','sus4'])for(const seventh of [null,'7','maj7'])for(const extension of [null,9,11,13])for(let inversion=0;inversion<4;inversion++){const c=build({letter,acc,quality,seventh,extension,inversion});assert.equal(c.bass.midi%12,c.bass.pc);assert.equal(new Set(c.voiced.map(n=>n.pc)).size,c.components.length);assert.ok(c.voiced.every((t,i,ns)=>!i||t.midi>ns[i-1].midi));const names={C:0,D:2,E:4,F:5,G:7,A:9,B:11};for(const t of c.components){let n=names[t.name[0]];for(const a of Array.from(t.name.slice(1)))n+=({'♯':1,'♭':-1,'𝄪':2,'𝄫':-2}[a]||0);assert.equal((n%12+12)%12,t.pc)}tested++}
console.log('PASS: '+cases.length+' named chords, inversion/order assertions, '+tested+' structure/spelling/voicing cases');
