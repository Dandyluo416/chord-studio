const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),H=require('../js/harmony-engine.js');
const source=fs.readFileSync(require('node:path').join(__dirname,'../js/legacy-1.js'),'utf8');const qs=JSON.parse(JSON.stringify(vm.runInNewContext(source.slice(source.indexOf('const qualities='),source.indexOf('const $='))+'qualities')));
let checks=0;function eq(a,b,name){assert.deepEqual(a,b,name);checks++}const bs=arr=>arr.map(([root,quality])=>({root,quality}));
eq(H.names(1,qs[0],null,'C♯'),['C♯','E♯','G♯'],'C# major');eq(H.names(1,qs[1],null,'C♯'),['C♯','E','G♯'],'C# minor');eq(H.names(1,qs[7],null,'C♯'),['C♯','E♯','G♯','B♯'],'C# maj7');eq(H.names(0,qs[10],null,'C'),['C','E♭','G♭','B𝄫'],'dim7');eq(H.names(1,qs[7],{tonic:1,mode:'major'}),['D♭','F','A♭','C'],'Db context');
let a=H.analyze(bs([[0,0],[9,1],[5,0],[7,0]]),qs);eq(a.key.tonic,0,'C Am F G tonic');eq(a.key.mode,'major','C major');eq(a.functions.map(f=>f.label),['I','vi','IV','V'],'diatonic roman');
a=H.analyze(bs([[0,0],[2,6],[7,6],[0,0]]),qs);eq(a.key.tonic,0,'secondary does not modulate');eq(a.functions[1].label,'V7/V','secondary');
a=H.analyze(bs([[0,0],[5,1],[7,6],[0,0]]),qs);eq(a.key.tonic,0,'borrowed iv');eq(a.functions[1].kind,'borrowed','borrowed classification');eq(a.functions[2].label,'V7','dominant');
a=H.analyze(bs([[0,0],[11,10],[0,0]]),qs,{tonic:0,mode:'major'});eq(a.functions[1].label,'vii°7/I','diminished resolution');eq(a.functions[1].names,['B','D','F','A♭'],'Bdim7 spelling');
a=H.analyze(bs([[0,0],[8,6],[7,6],[0,0]]),qs,{tonic:0,mode:'major'});eq(a.functions[1].label,'Ger+6','augmented-sixth interpretation');
a=H.analyze(bs([[0,0],[7,6],[0,0],[2,6],[7,0],[2,6],[7,0]]),qs,{tonic:0,mode:'major'});eq(a.modulations.some(m=>m.tonic===7),true,'related modulation');
a=H.analyze(bs([[0,0],[7,6],[0,0],[8,6],[1,0],[8,6],[1,0]]),qs,{tonic:0,mode:'major'});eq(a.modulations.some(m=>m.tonic===1),true,'distant modulation');
a=H.analyze(bs([[0,0],[9,1]]),qs);eq(a.uncertain,true,'ambiguous marked');
for(const mode of ['major','minor'])for(let tonic=0;tonic<12;tonic++)for(let r=0;r<12;r++)for(const q of qs){const ns=H.names(r,q,{tonic,mode});ns.forEach((n,i)=>eq(H.pc(n),(r+q[2][i])%12,'enharmonic MIDI agreement'))}
console.log('PASS '+checks+' spelling/key/function checks (10 harmonic categories)');
