"""Digital mix test of retained piano samples. Does NOT measure a real microphone."""
import json,base64,subprocess,tempfile,pathlib,numpy as np
root=pathlib.Path(__file__).resolve().parent.parent
text=(root/'js/piano-samples.js').read_text();data=json.loads(text[text.index('{'):].rstrip(';\n '))
rate=48000; size=16384
cases=[[48,52,55],[60,64,67],[57,60,64],[60,64,67,71],[59,60,64,67],[48],[48,60,64,67]]
cache={}
with tempfile.TemporaryDirectory() as td:
 for note in set(n for ns in cases for n in ns):
  key=str(note) if str(note) in data else min(data,key=lambda k:abs(int(k)-note))
  p=pathlib.Path(td)/'note.mp3';p.write_bytes(base64.b64decode(data[key].split(',')[1]))
  raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-f','f32le','-ac','1','-ar',str(rate),'-'])
  pcm=np.frombuffer(raw,dtype='<f4');ratio=2**((note-int(key))/12)
  cache[note]=np.interp(np.arange(int(len(pcm)/ratio))*ratio,np.arange(len(pcm)),pcm)
 payload=[]
 for notes in cases:
  count=min(len(cache[n]) for n in notes);mix=sum(cache[n][:count] for n in notes)/len(notes)
  for seconds in [.12,.3,.5]:
   start=int(seconds*rate);x=mix[start:start+size]
   if len(x)<size: x=np.pad(x,(0,size-len(x)))
   spec=np.abs(np.fft.rfft(x*np.blackman(size)))[:size//2]/(size/2)
   db=20*np.log10(spec+1e-10)
   payload.append({'notes':notes,'time':seconds,'db':db.tolist()})
 p=pathlib.Path(td)/'spectra.json';p.write_text(json.dumps(payload))
 script="const P=require('./js/poly-engine.js'),fs=require('fs');const cases=JSON.parse(fs.readFileSync(process.argv[1]));let results=cases.map(c=>{const start=performance.now();const detected=P.detect(c.db,48000,16384);return {expected:c.notes,seconds:c.time,detected,match:P.match(detected,c.notes.map(n=>n%12)),ms:+(performance.now()-start).toFixed(3)}});console.log(JSON.stringify({kind:'Digitally mixed original MP3 piano samples; no microphone',passed:results.filter(r=>r.match).length,total:results.length,results},null,2));"
 report=subprocess.check_output(['node','-e',script,str(p)],cwd=root,text=True)
 (root/'tests/sampled-piano-results.json').write_text(report);print(report)
